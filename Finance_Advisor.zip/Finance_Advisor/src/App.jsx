import { useState } from "react";
import { Routes, Route, useLocation, Navigate } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import "./App.css";

import Login from "./Pages/Login";
import Home from "./Pages/Home";
import Dashboard from "./Pages/Dashboard";
import Reports from "./Pages/Reports";
import Register from "./Pages/Register";
import Transactions from "./Pages/Transactions";
import Settings from "./Pages/Settings";
import Profile from "./Pages/Profile";
import History from "./Pages/History";

import AdminLayout from "./Admin_Page/AdminLayout";
import AdminDashboard from "./Admin_Page/AdminDashboard";
import AdminUsers from "./Admin_Page/AdminUsers";
import AdminTransactions from "./Admin_Page/AdminTransaction";
import AdminAnalytics from "./Admin_Page/AdminAnalytics";
import AdminLogs from "./Admin_Page/AdminLogs";
import AdminAISuggestions from "./Admin_Page/AdminAISuggestions";
import AdminUserDetails from "./Admin_Page/AdminUserDetails";
import { AnimatePresence } from "framer-motion";

function App() {
  const location = useLocation();
  const [transactions, setTransactions] = useState([]);

  return (
    <AnimatePresence mode="sync">
      <ToastContainer position="top-right" autoClose={2000} theme="colored" />
      <Routes location={location} key={location.pathname}>
        {/* Public Routes */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* User Dashboard */}
        <Route
          path="/dashboard"
          element={
            <Dashboard
              transactions={transactions}
              setTransactions={setTransactions}
            />
          }
        >
          <Route path="transactions" element={<Transactions />} />
          <Route path="reports" element={<Reports />} />
          <Route path="settings" element={<Settings />} />
          <Route path="profile" element={<Profile />} />
          <Route path="history" element={<History />} />
        </Route>

        {/* ================= ADMIN PANEL ================= */}

        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<AdminDashboard />} />

          <Route path="users" element={<AdminUsers />} />

          <Route path="users/:id" element={<AdminUserDetails />} />

          <Route path="transactions" element={<AdminTransactions />} />

          <Route path="analytics" element={<AdminAnalytics />} />

          <Route path="logs" element={<AdminLogs />} />

          <Route path="ai-suggestion" element={<AdminAISuggestions />} />
        </Route>

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </AnimatePresence>
  );
}

export default App;
