import API from "./apiClient";

export const getTransactions = () => API.get("/transactions/");

export const createTransaction = (data) =>
  API.post("/transactions/", data);

export const deleteTransactionApi = (id) =>
  API.delete(`/transactions/${id}`);