import React from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import "./Admin.css";

const AdminLayout = () => {
  const location = useLocation();

  return (
    <div className="admin-container">
      <aside className="admin-sidebar">
        <h2 className="admin-title">💰 Finance Admin</h2>

        <nav className="admin-nav">
          {/* Dashboard */}
          <NavLink
            to="/admin"
            className={() => (location.pathname === "/admin" ? "active" : "")}
          >
            📊 Dashboard
          </NavLink>

          {/* Users */}
          <NavLink
            to="/admin/users"
            className={({ isActive }) => (isActive ? "active" : "")}
          >
            👥 Users
          </NavLink>

          {/* Transactions */}
          <NavLink
            to="/admin/transactions"
            className={({ isActive }) => (isActive ? "active" : "")}
          >
            💳 Transactions
          </NavLink>

          {/* Analytics */}
          <NavLink
            to="/admin/analytics"
            className={({ isActive }) => (isActive ? "active" : "")}
          >
            📈 Analytics
          </NavLink>

          {/* AI */}
          <NavLink
            to="/admin/ai-suggestion"
            className={({ isActive }) => (isActive ? "active" : "")}
          >
            🤖 AI Suggestions
          </NavLink>

          {/* Logs */}
          <NavLink
            to="/admin/logs"
            className={({ isActive }) => (isActive ? "active" : "")}
          >
            📜 Logs
          </NavLink>
        </nav>
      </aside>

      <main className="admin-content">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            transition={{ duration: 0.35 }}
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
};

export default AdminLayout;
