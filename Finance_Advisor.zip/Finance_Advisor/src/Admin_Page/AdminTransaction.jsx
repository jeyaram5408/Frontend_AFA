import React,{useState} from "react";
import "./Admin.css";

const AdminTransactions = () => {

const [filter,setFilter] = useState("all")

const transactions = [
{ id:1,user:"Arun",type:"Income",amount:20000 },
{ id:2,user:"Priya",type:"Expense",amount:1500 },
{ id:3,user:"Rahul",type:"Expense",amount:4000 },
{ id:4,user:"Rahul",type:"Expense",amount:4000 }

]

const filteredTransactions =
filter==="all"
?transactions
:transactions.filter(t=>t.type===filter)

return(

<div>

<h1>Transactions</h1>

<select
value={filter}
onChange={(e)=>setFilter(e.target.value)}
>

<option value="all">All</option>
<option value="Income">Income</option>
<option value="Expense">Expense</option>

</select>

<table className="admin-table">

<thead>
<tr>
<th>ID</th>
<th>User</th>
<th>Type</th>
<th>Amount</th>
</tr>
</thead>

<tbody>

{filteredTransactions.map((t)=>(
<tr key={t.id}>
<td>{t.id}</td>
<td>{t.user}</td>
<td>{t.type}</td>
<td>₹{t.amount}</td>
</tr>
))}

</tbody>
</table>

</div>

)

}

export default AdminTransactions