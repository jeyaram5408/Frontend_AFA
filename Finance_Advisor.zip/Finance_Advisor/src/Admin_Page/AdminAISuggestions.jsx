import React from "react";
import "./Admin.css";

const AdminAISuggestions = () => {
  const suggestions = [
    {
      id: 1,
      user: "Arun",
      suggestion: "Reduce food expenses by 10%",
      status: "accepted",
    },
    {
      id: 2,
      user: "Priya",
      suggestion: "Increase savings",
      status: "rejected",
    },
  ];

  return (
    <div>
      <h1>AI Suggestions</h1>

      <table className="admin-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>User</th>
            <th>Suggestion</th>
            <th>Status</th>
          </tr>
        </thead>

        <tbody>
          {suggestions.map((s) => (
            <tr key={s.id}>
              <td>{s.id}</td>
              <td>{s.user}</td>
              <td>{s.suggestion}</td>
              <td>
                <span
                  className={
                    s.status === "accepted" ? "status-active" : "status-block"
                  }
                >
                  {s.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AdminAISuggestions;
