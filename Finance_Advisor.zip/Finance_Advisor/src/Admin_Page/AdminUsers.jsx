import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import "./Admin.css";

const AdminUsers = () => {

const [search,setSearch] = useState("");

const users = [
{
id:1,
name:"Arun",
email:"arun@gmail.com",
status:"active",
lastLogin:"2026-03-05"
},
{
id:2,
name:"Priya",
email:"priya@gmail.com",
status:"blocked",
lastLogin:"2026-03-04"
},
{
id:3,
name:"Rahul",
email:"rahul@gmail.com",
status:"active",
lastLogin:"2026-03-03"
},
{
id:4,
name:"Rahul",
email:"rahul@gmail.com",
status:"active",
lastLogin:"2026-03-03"
}
]

const filteredUsers = users.filter((user)=>
user.name.toLowerCase().includes(search.toLowerCase())
)

return (

<motion.div initial={{opacity:0}} animate={{opacity:1}}>

<h1 className="admin-heading">User Management</h1>

<input
type="text"
placeholder="Search users..."
value={search}
onChange={(e)=>setSearch(e.target.value)}
className="search-input"
/>

<table className="admin-table">

<thead>
<tr>
<th>ID</th>
<th>Name</th>
<th>Email</th>
<th>Status</th>
<th>Last Login</th>
<th>Actions</th>
</tr>
</thead>

<tbody>

{filteredUsers.map((user)=>(
<tr key={user.id}>

<td>{user.id}</td>
<td>{user.name}</td>
<td>{user.email}</td>

<td>
<span className={
user.status==="active"
?"status-active"
:"status-block"
}>
{user.status}
</span>
</td>

<td>{user.lastLogin}</td>

<td>

<Link to={`/admin/users/${user.id}`}>
<button className="freeze-btn">
View
</button>
</Link>

<button className="freeze-btn">
Freeze
</button>

<button className="delete-btn">
Delete
</button>

</td>

</tr>
))}

</tbody>
</table>

</motion.div>

)

}

export default AdminUsers