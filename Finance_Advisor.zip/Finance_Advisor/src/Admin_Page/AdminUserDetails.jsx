import React, { useState } from "react";
import { useParams } from "react-router-dom";
import "./Admin.css";
import BackButton from "./BackButton";
const AdminUserDetails = () => {
  const { id } = useParams();

  // Mock transaction data per user
  const transactions = [
    { id: 1, type: "Income", amount: 20000, description: "Salary", userId: 1 },
    { id: 2, type: "Expense", amount: 5000, description: "Food", userId: 1 },
    {
      id: 3,
      type: "Expense",
      amount: 3000,
      description: "Transport",
      userId: 1,
    },
    {
      id: 4,
      type: "Income",
      amount: 15000,
      description: "Freelance",
      userId: 2,
    },
    {
      id: 5,
      type: "Expense",
      amount: 7000,
      description: "Shopping",
      userId: 2,
    },
  ];

  const users = [
    { id: 1, name: "Arun", email: "arun@gmail.com", joinDate: "2025-10-12" },
    { id: 2, name: "Priya", email: "priya@gmail.com", joinDate: "2025-09-20" },
  ];

  const user = users.find((u) => u.id === parseInt(id));

  if (!user) return <p>User not found!</p>;

  // Filter transactions for this user
  const userTransactions = transactions.filter((t) => t.userId === user.id);

  // Calculate totals
  const totalIncome = userTransactions
    .filter((t) => t.type === "Income")
    .reduce((sum, t) => sum + t.amount, 0);
  const totalExpense = userTransactions
    .filter((t) => t.type === "Expense")
    .reduce((sum, t) => sum + t.amount, 0);
  const savings = totalIncome - totalExpense;

  // State to filter transactions
  const [filter, setFilter] = useState("all");

  const filteredTransactions =
    filter === "all"
      ? userTransactions
      : userTransactions.filter((t) => t.type === filter);

  return (
    <div>
      <div style={{ marginBottom: "20px" }}>
        <BackButton />
      </div>

      <h1 className="admin-heading">User Details</h1>

      <p>
        <strong>Name:</strong> {user.name}
      </p>
      <p>
        <strong>Email:</strong> {user.email}
      </p>
      <p>
        <strong>Join Date:</strong> {user.joinDate}
      </p>
      <p>
        <strong>Total Income:</strong> ₹{totalIncome}
      </p>
      <p>
        <strong>Total Expense:</strong> ₹{totalExpense}
      </p>
      <p>
        <strong>Savings:</strong> ₹{savings}
      </p>

      <hr style={{ margin: "20px 0" }} />

      <h2>Transactions</h2>

      <select value={filter} onChange={(e) => setFilter(e.target.value)}>
        <option value="all">All</option>
        <option value="Income">Income</option>
        <option value="Expense">Expense</option>
      </select>

      <table className="admin-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Type</th>
            <th>Description</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
          {filteredTransactions.map((t) => (
            <tr key={t.id}>
              <td>{t.id}</td>
              <td>{t.type}</td>
              <td>{t.description}</td>
              <td>₹{t.amount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AdminUserDetails;
