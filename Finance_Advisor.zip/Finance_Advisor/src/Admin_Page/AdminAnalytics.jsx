import React from "react";
import {
BarChart, Bar, XAxis, YAxis, Tooltip,
PieChart, Pie, Cell, ResponsiveContainer
} from "recharts";
import "./Admin.css";

const AdminAnalytics = () => {

const userGrowth = [
{month:"Jan",users:10},
{month:"Feb",users:20},
{month:"Mar",users:35},
{month:"Apr",users:50}
];

const categories = [
{category:"Food",count:40},
{category:"Shopping",count:25},
{category:"Transport",count:15}
];

const COLORS=["#6366f1","#22c55e","#f97316"];

const suggestions=[
{status:"accepted"},
{status:"accepted"},
{status:"rejected"},
{status:"accepted"}
];

const accepted = suggestions.filter(
(s)=>s.status==="accepted"
).length;

const accuracy = Math.round(
(accepted/suggestions.length)*100
);

return(

<div>

<h1 className="admin-heading">
Platform Analytics
</h1>

<div className="analytics-grid">

{/* User Growth Chart */}

<div className="analytics-card">

<h3 className="chart-title">
User Growth
</h3>

<ResponsiveContainer width="100%" height={250}>
<BarChart data={userGrowth}>
<XAxis dataKey="month"/>
<YAxis/>
<Tooltip/>
<Bar dataKey="users" fill="#6366f1"/>
</BarChart>
</ResponsiveContainer>

</div>

{/* Category Chart */}

<div className="analytics-card">

<h3 className="chart-title">
Expense Categories
</h3>

<ResponsiveContainer width="100%" height={250}>
<PieChart>

<Pie
data={categories}
dataKey="count"
nameKey="category"
outerRadius={90}
label
>

{categories.map((entry,index)=>(
<Cell
key={index}
fill={COLORS[index%COLORS.length]}
/>
))}

</Pie>

<Tooltip/>

</PieChart>
</ResponsiveContainer>

</div>

</div>

{/* AI Accuracy */}

<div className="ai-card">

<h3>AI Suggestion Accuracy</h3>

<p>{accuracy}%</p>

</div>

</div>

)

}

export default AdminAnalytics