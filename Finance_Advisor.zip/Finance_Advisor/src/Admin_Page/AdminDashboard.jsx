import React from "react";
import { motion } from "framer-motion";
import "./Admin.css";

const AdminDashboard = () => {

  const stats = [
    { title: "Total Users", value: 120 },
    { title: "Active Users", value: 95 },
    { title: "Blocked Users", value: 25 },
    { title: "Total Transactions", value: 540 }
  ];

  return (
    
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
    >

      <h1 className="admin-heading">Admin Dashboard</h1>

      <div className="admin-cards">

        {stats.map((card, index) => (

          <motion.div
            key={index}
            className="card"
            whileHover={{ scale: 1.05 }}
          >

            <h3>{card.title}</h3>
            <p>{card.value}</p>

          </motion.div>

        ))}

      </div>

    </motion.div>

  );
};

export default AdminDashboard;