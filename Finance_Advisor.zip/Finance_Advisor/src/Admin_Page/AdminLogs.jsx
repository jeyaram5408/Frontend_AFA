import React from "react";
import "./Admin.css";

const AdminLogs = () => {

  const logs = [
    { id: 1, action: "User Login", user: "Arun", date: "2026-03-05" },
    { id: 2, action: "Transaction Added", user: "Priya", date: "2026-03-05" },
    { id: 3, action: "User Deleted", user: "Admin", date: "2026-03-04" },
  ];

  return (
    <div>

      <h1>System Logs</h1>

      <table className="admin-table">

        <thead>
          <tr>
            <th>ID</th>
            <th>Action</th>
            <th>User</th>
            <th>Date</th>
          </tr>
        </thead>

        <tbody>

          {logs.map((log) => (
            <tr key={log.id}>
              <td>{log.id}</td>
              <td>{log.action}</td>
              <td>{log.user}</td>
              <td>{log.date}</td>
            </tr>
          ))}

        </tbody>

      </table>

    </div>
  );
};

export default AdminLogs;