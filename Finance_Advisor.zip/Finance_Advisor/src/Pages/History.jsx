import React, { useState, useMemo } from "react";
import { useLocation } from "react-router-dom";

const History = () => {
  const location = useLocation();
  const transactions = location.state?.transactions || [];
  const [filter, setFilter] = useState("all");

  // ✅ Filter + Sort Optimized
  const filteredTransactions = useMemo(() => {
    const today = new Date();

    // ✅ ALL DATA
    if (filter === "all") {
      return [...transactions].sort(
        (a, b) => new Date(b.date) - new Date(a.date),
      );
    }

    // ✅ Last 10
    if (filter === "last10") {
      return [...transactions]
        .sort((a, b) => new Date(b.date) - new Date(a.date))
        .slice(0, 10);
    }

    let days = 7;

    if (filter === "1m") days = 30;
    if (filter === "3m") days = 90;
    if (filter === "6m") days = 180;
    if (filter === "1y") days = 365;

    const pastDate = new Date();
    pastDate.setDate(today.getDate() - days);

    return transactions
      .filter((t) => {
        if (!t.date) return false;
        const tDate = new Date(t.date);
        return tDate >= pastDate && tDate <= today;
      })
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [transactions, filter]);

  return (
    <div className="space-y-6">
      {/* Title */}
      <h2 className="text-3xl font-bold">Transaction History</h2>

      {/* Filter */}
      <select
        value={filter}
        onChange={(e) => setFilter(e.target.value)}
        className="border px-3 h-10 rounded-lg focus:outline-none focus:ring-2 focus:ring-BLACK-400"
      >
        <option value="7d">Last 7 Days</option>
        <option value="last10">Last 10 Transactions</option>
        <option value="1m">1 Month</option>
        <option value="3m">3 Months</option>
        <option value="6m">6 Months</option>
        <option value="1y">1 Year</option>
      </select>

      {/* List */}
      <div className="space-y-3">
        {filteredTransactions.length === 0 ? (
          <div className="text-center py-10 text-gray-500">
            No Transactions Found 🚫
          </div>
        ) : (
          filteredTransactions.map((t) => (
            <div
              key={t.id}
              className={`flex justify-between items-center p-4 rounded-lg shadow-sm ${
                t.type === "income" ? "bg-green-50" : "bg-red-50"
              }`}
            >
              <div>
                <p className="font-semibold">{t.title}</p>
                <p className="text-sm text-gray-500">
                  {t.category} • {t.date}
                </p>
              </div>

              <p
                className={`font-bold text-lg ${
                  t.type === "income" ? "text-green-600" : "text-red-600"
                }`}
              >
                ₹ {Number(t.amount).toLocaleString()}
              </p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default History;
