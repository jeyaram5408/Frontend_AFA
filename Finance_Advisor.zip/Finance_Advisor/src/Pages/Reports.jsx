import React from "react";
import { useOutletContext } from "react-router-dom";
import { calculateFinancialHealth } from "../Utils/financial_calculater";
import { calculateExpenseForecast } from "../Utils/forecast";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { motion } from "framer-motion";
const Reports = () => {
  const { transactions = [] } = useOutletContext();

  const { income, expense, savings, score, message } =
    calculateFinancialHealth(transactions);

  const {
    monthlyAverage,
    nextMonthPrediction,
    sixMonthProjection,
  } = calculateExpenseForecast(transactions);

  const expenseRatio = income > 0 ? (expense / income) * 100 : 0;

  const getBudgetAdvice = () => {
    if (income === 0)
      return "Add income transactions to unlock financial insights.";

    if (expenseRatio > 70)
      return "⚠️ Your spending is high. Try reducing expenses.";

    if (expenseRatio > 50)
      return "💡 You can improve your savings rate.";

    return "✅ Excellent budgeting discipline.";
  };

  const adviceMessage = getBudgetAdvice();

  // ===== SAFE MONTHLY TREND =====

  const monthlyMap = {};

  transactions.forEach((tx) => {
    if (!tx.date) return;

    const dateObj = new Date(tx.date);
    const key = `${dateObj.getFullYear()}-${dateObj.getMonth()}`;

    if (!monthlyMap[key]) {
      monthlyMap[key] = {
        month: dateObj.toLocaleString("default", { month: "short" }),
        income: 0,
        expense: 0,
      };
    }

    if (tx.type?.toLowerCase() === "income") {
      monthlyMap[key].income += Number(tx.amount);
    } else {
      monthlyMap[key].expense += Number(tx.amount);
    }
  });

  const chartData = Object.values(monthlyMap);

return (
  <motion.div
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    transition={{ duration: 0.6 }}
    className="space-y-10 max-w-6xl mx-auto"
  >

      <div>
        <h2 className="text-3xl font-bold text-gray-800">
          Reports & Insights
        </h2>
      </div>

      {/* SUMMARY */}
      <div className="grid md:grid-cols-3 gap-6">

        <div className="bg-white p-6 rounded-2xl shadow border">
          <p className="text-sm text-gray-500">Financial Score</p>
          <h3 className="text-4xl font-bold text-indigo-600 mt-2">
            {score}%
          </h3>
          <p className="text-sm mt-2">{message}</p>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow border">
          <p className="text-sm text-gray-500">Savings</p>
          <h3 className="text-4xl font-bold text-green-600 mt-2">
            ₹{savings.toFixed(2)}
          </h3>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow border">
          <p className="text-sm text-gray-500">Expense Ratio</p>
          <h3 className="text-4xl font-bold text-red-500 mt-2">
            {expenseRatio.toFixed(1)}%
          </h3>
        </div>
      </div>

      {/* TREND */}
      <div className="bg-white p-6 rounded-2xl shadow border min-h-105">
        <h3 className="text-lg font-semibold mb-4">
          Monthly Financial Trend
        </h3>

        {chartData.length === 0 ? (
          <p className="text-gray-400 text-center mt-20">
            No transaction data available
          </p>
        ) : (
          <ResponsiveContainer width="100%" height={350}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="income" stroke="#10B981" strokeWidth={3} />
              <Line type="monotone" dataKey="expense" stroke="#EF4444" strokeWidth={3} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>

      {/* FORECAST */}
      <div className="grid md:grid-cols-2 gap-6">

        <div className="bg-indigo-600 text-white p-8 rounded-2xl shadow-lg">
          <h3 className="text-lg font-semibold">Expense Forecast</h3>
          <div className="mt-4 space-y-2">
            <p>Monthly Avg: ₹{monthlyAverage.toFixed(2)}</p>
            <p>Next Month: ₹{nextMonthPrediction.toFixed(2)}</p>
            <p>6 Month Projection: ₹{sixMonthProjection.toFixed(2)}</p>
          </div>
        </div>

        <div className="bg-linear-to-r from-purple-500 to-indigo-600 text-white p-8 rounded-2xl shadow-lg">
          <h3 className="text-lg font-semibold">AI Insight</h3>
          <p className="mt-4">{adviceMessage}</p>
        </div>

      </div>

    </motion.div>
  );
};

export default Reports;