import React, { useState, useEffect } from "react";
import axios from "axios";
import API from "../api/apiClient";
import add_icon from "../assets/add-circle-svgrepo-com.svg";

import {
  getCategories,
  createCategory,
  deleteCategory,
} from "../api/categoryApi"; // path adjust panniko

const Settings = () => {
  const [alertThreshold, setAlertThreshold] = useState(80);

  const [isEditingIncome, setIsEditingIncome] = useState(false);
  const [isEditingExpense, setIsEditingExpense] = useState(false);

  const [showIncomeForm, setShowIncomeForm] = useState(false);
  const [showExpenseForm, setShowExpenseForm] = useState(false);

  const [showEditIncomeForm, setShowEditIncomeForm] = useState(false);
  const [selectedIncome, setSelectedIncome] = useState(null);

  const [editValue, setEditValue] = useState("");

  const [categories, setCategories] = useState({
    income: [],
    expense: [],
  });

  const [newIncome, setNewIncome] = useState("");
  const [newExpense, setNewExpense] = useState("");

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const res = await getCategories();

      const income = res.data.filter((c) => c.type === "income");
      const expense = res.data.filter((c) => c.type === "expense");

      setCategories({
        income,
        expense,
      });
    } catch (err) {
      console.error(err);
    }
  };

  const addIncomeCategory = async () => {
    if (newIncome.trim() === "") return;

    await createCategory({
      name: newIncome,
      type: "income",
    });

    setNewIncome("");
    fetchCategories();
  };

  const addExpenseCategory = async () => {
    if (newExpense.trim() === "") return;

    await createCategory({
      name: newExpense,
      type: "expense",
    });

    setNewExpense("");
    fetchCategories();
  };
  const saveIncomeEdit = async () => {
    if (!editValue.trim()) return;

    // 👉 backend update API (you must create)
    await API.patch(`/categories/${selectedIncome.id}`, {
      name: editValue,
      type: selectedIncome.type, // 🔥 important
    });
    setShowEditIncomeForm(false);
    setEditValue("");
    setSelectedIncome(null);
    fetchCategories();
  };

  const handleDeleteIncome = async (id) => {
    await deleteCategory(id);
    fetchCategories();
  };

  const handleDeleteExpense = async (id) => {
    await deleteCategory(id);
    fetchCategories();
  };

  return (
    <div className="p-8 bg-gray-50 min-h-screen space-y-10">
      <h1 className="text-3xl font-bold text-gray-800">Settings</h1>
      {showEditIncomeForm && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center">
          <div className="bg-white p-6 rounded-xl w-96 space-y-4 shadow-lg">
            <h3 className="text-lg font-semibold">Edit Category</h3>

            <input
              value={editValue}
              onChange={(e) => setEditValue(e.target.value)}
              className="w-full border p-2 rounded-lg"
            />

            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowEditIncomeForm(false)}
                className="px-4 py-1 border rounded-lg"
              >
                Close
              </button>

              <button
                onClick={saveIncomeEdit}
                className="bg-green-600 text-white px-4 py-1 rounded-lg"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
      {/* INCOME */}
      <div className="bg-white p-8 rounded-2xl shadow border">
        <div className="flex justify-between mb-6">
          <h3 className="text-xl font-semibold">Income Categories</h3>

          <div className="flex gap-4">
            <button
              onClick={() => setIsEditingIncome(!isEditingIncome)}
              className="text-blue-600"
            >
              Edit
            </button>

            <button
              onClick={() => setShowIncomeForm(true)}
              className="text-green-600 w-5 cursor-pointer"
            >
              <img src={add_icon} alt="Add" />
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-3">
          {categories.income.map((cat, index) => (
            <div
              key={index}
              className="px-4 py-2 bg-green-100 rounded-full flex items-center gap-2"
            >
              <span
                onClick={() => {
                  if (isEditingIncome) {
                    setSelectedIncome(cat);
                    setEditValue(cat.name);
                    setShowEditIncomeForm(true);
                  }
                }}
                className="cursor-pointer"
              >
                {cat.name}
              </span>

              {isEditingIncome && (
                <button onClick={() => handleDeleteIncome(cat.id)}>✖</button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* INCOME */}
      {showIncomeForm && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center">
          <div className="bg-white p-6 rounded-xl w-96 space-y-4 shadow-lg">
            <h3 className="text-lg font-semibold">Add Income Category</h3>

            <input
              value={newIncome}
              onChange={(e) => setNewIncome(e.target.value)}
              className="w-full border p-2 rounded-lg"
            />

            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowIncomeForm(false)}
                className="px-4 py-1 border rounded-lg"
              >
                Close
              </button>

              <button
                onClick={addIncomeCategory}
                className="bg-green-600 text-white px-4 py-1 rounded-lg"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* EXPENSE */}
      <div className="bg-white p-8 rounded-2xl shadow border">
        <div className="flex justify-between mb-6">
          <h3 className="text-xl font-semibold">Expense Categories</h3>

          <div className="flex gap-4">
            <button
              onClick={() => setIsEditingExpense(!isEditingExpense)}
              className="text-blue-600"
            >
              Edit
            </button>

            <button
              onClick={() => setShowExpenseForm(!showExpenseForm)}
              className="text-indigo-600 w-5 h-5 hover:scale-110 transition cursor-pointer"
            >
              <img src={add_icon} alt="Add" />
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-3">
          {categories.expense.map((cat, index) => (
            <div
              key={index}
              className="px-4 py-2 bg-red-100 rounded-full flex items-center gap-2 shadow-sm"
            >
              <span>{cat.name}</span>

              {isEditingExpense && (
                <button onClick={() => handleDeleteExpense(cat.id)}>✖</button>
              )}
            </div>
          ))}
        </div>

        {showExpenseForm && (
          <div className="mt-5 flex gap-3">
            <input
              value={newExpense}
              onChange={(e) => setNewExpense(e.target.value)}
              className="border p-2 rounded-lg w-full"
            />
            <button
              onClick={addExpenseCategory}
              className="bg-indigo-600 text-white px-4 rounded-lg"
            >
              Add
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Settings;
