import React, { useState } from "react";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import {
  FaBell,
  FaUserCircle,
  FaHome,
  FaExchangeAlt,
  FaChartLine,
  FaCog,
  FaHistory
} from "react-icons/fa";
import { motion } from "framer-motion";
import FinancialHealthScore from "../components/FinancialHealthScore";
import ExpensePieChart from "../components/ExpensePieChart";
import SmartRecommendations from "../components/SmartRecommendations";
import { calculateFinancialHealth } from "../Utils/financial_calculater";
import logo from "../assets/logo.png";
import BudgetGoal from "../components/BudgetGoal";
const Dashboard = ({ transactions, setTransactions }) => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [profileOpen, setProfileOpen] = useState(false);

  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    navigate("/login");
  };

  const isDashboardHome = location.pathname === "/dashboard";

  return (
    <div className="flex bg-gray-100 min-h-screen">
      {/* ================= Sidebar ================= */}
      <div
        className={`${
          sidebarOpen ? "w-56" : "w-20"
        } bg-indigo-700 text-white transition-all duration-300 fixed h-screen flex flex-col`}
      >
        {/* Logo */}
        <div
          className="p-5 flex items-center justify-center cursor-pointer border-b border-indigo-600"
          onClick={() => setSidebarOpen(!sidebarOpen)}
        >
          <img src={logo} alt="logo" className="w-10 h-10 rounded-3xl" />
        </div>

        {/* Navigation */}
        <nav className="flex-1 mt-6 space-y-3 px-3">
          <SidebarItem
            icon={<FaHome />}
            label="Dashboard"
            active={location.pathname === "/dashboard"}
            onClick={() => navigate("/dashboard")}
            sidebarOpen={sidebarOpen}
          />

          <SidebarItem
            icon={<FaExchangeAlt />}
            label="Transactions"
            active={location.pathname.includes("transactions")}
            onClick={() => navigate("/dashboard/transactions")}
            sidebarOpen={sidebarOpen}
          />

          <SidebarItem
            icon={<FaChartLine />}
            label="Reports"
            active={location.pathname.includes("reports")}
            onClick={() => navigate("/dashboard/reports")}
            sidebarOpen={sidebarOpen}
          />

          <SidebarItem
            icon={<FaCog />}
            label="Settings"
            active={location.pathname.includes("settings")}
            onClick={() => navigate("/dashboard/settings")}
            sidebarOpen={sidebarOpen}
          />
            
            <SidebarItem
            icon={<FaHistory />}
            label="History"
            active={location.pathname.includes("history")}
            onClick={() => navigate("/dashboard/history")}
            sidebarOpen={sidebarOpen}
          /> 

        </nav>
      </div>

      {/* ================= Main Content ================= */}
      <div
        className={`flex-1 flex flex-col transition-all duration-300 ${
          sidebarOpen ? "ml-56" : "ml-20"
        }`}
      >
        {/* ================= Navbar ================= */}
        <div
          className="flex justify-between items-center bg-white px-6 py-6 shadow fixed top-0 right-0 z-40 transition-all duration-300"
          style={{
            left: sidebarOpen ? "224px" : "80px",
            right: "0",
          }}
        >
          <h1 className="text-2xl font-bold text-gray-700">
            {location.pathname.includes("transactions")
              ? "Transactions"
              : location.pathname.includes("reports")
                ? "Reports"
                : location.pathname.includes("settings")
                  ? "Settings"
                  : "Dashboard"}
          </h1>

          <div className="flex items-center gap-6 relative">
            <FaBell className="text-xl text-gray-600 cursor-pointer hover:text-indigo-600 transition" />

            <div
              className="relative cursor-pointer"
              onClick={() => setProfileOpen(!profileOpen)}
            >
              <FaUserCircle className="text-3xl text-indigo-600" />

              {profileOpen && (
                <div className="absolute right-0 mt-3 w-40 bg-white shadow-lg rounded-lg border">
                  <div
                    onClick={() => navigate("/dashboard/profile")}
                    className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                  >
                    Profile
                  </div>
                  <div
                    onClick={handleLogout}
                    className="px-4 py-2 hover:bg-red-100 text-red-600 cursor-pointer"
                  >
                    Logout
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ================= Page Content ================= */}
        <div className="pt-24 px-6 pb-10 overflow-y-auto min-h-screen">
          {isDashboardHome ? (
            <DashboardHome transactions={transactions} />
          ) : (
            <Outlet context={{ transactions, setTransactions }} />
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

/* ================= Sidebar Item ================= */

function SidebarItem({ icon, label, active, onClick, sidebarOpen }) {
  return (
    <div
      onClick={onClick}
      className={`flex items-center gap-4 p-3 rounded-lg cursor-pointer transition-all duration-200 ${
        active
          ? "bg-white text-indigo-700 font-semibold border-l-4 border-indigo-600 shadow"
          : "hover:bg-indigo-600"
      }`}
    >
      <div className="text-lg">{icon}</div>
      {sidebarOpen && <span className="text-sm">{label}</span>}
    </div>
  );
}

/* ================= Dashboard Home ================= */

function DashboardHome({ transactions }) {
  const { income, expense, savings } = calculateFinancialHealth(transactions);

  return (
    <div className="space-y-6">
      {/* ===== Top Cards ===== */}
      <motion.div
        className="grid md:grid-cols-3 gap-6"
        initial="hidden"
        animate="visible"
        variants={{
          hidden: {},
          visible: {
            transition: {
              staggerChildren: 0.2,
            },
          },
        }}
      >
        <Card title="Total Income" value={`₹ ${income.toLocaleString()}`} />
        <Card title="Total Expense" value={`₹ ${expense.toLocaleString()}`} />
        <Card title="Savings" value={`₹ ${savings.toLocaleString()}`} />
      </motion.div>

      {/* ===== Pie Chart + Health Score ===== */}
      <div className="grid md:grid-cols-2 gap-6">
        <ExpensePieChart transactions={transactions} />
        <BudgetGoal />

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          whileHover={{ scale: 1.03 }}
        >
          <FinancialHealthScore transactions={transactions} />
        </motion.div>
      </div>

      {/* ===== Smart Recommendations ===== */}
      <SmartRecommendations income={income} expense={expense} />
    </div>
  );
}

/* ================= Card Component ================= */

function Card({ title, value }) {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 30 },
        visible: { opacity: 1, y: 0 },
      }}
      whileHover={{ scale: 1.05 }}
      transition={{ duration: 0.4 }}
      className="bg-white p-6 rounded-2xl shadow-md border border-gray-100"
    >
      <h3 className="text-gray-500">{title}</h3>
      <p className="text-2xl font-bold mt-2">{value}</p>
    </motion.div>
  );
}
