import React, { useState } from "react";
import { motion } from "framer-motion";
import { FaEnvelope, FaPhone, FaUserShield } from "react-icons/fa";

const Profile = () => {
  const [user, setUser] = useState({
    name: "Ram Kumar",
    email: "ram@example.com",
    phone: "9876543210",
    role: "User",
  });

  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  return (
    <motion.div
      className="p-6"
      initial={{ opacity: 0, y: 25 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      {/* Page Title */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Profile Overview</h1>
        <p className="text-gray-500 text-sm">
          View and update your personal details
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        
        {/* LEFT PROFILE SUMMARY */}
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="bg-white p-6 rounded-2xl shadow-md border border-gray-100 text-center space-y-4"
        >
          <div className="w-24 h-24 mx-auto rounded-full bg-indigo-600 text-white flex items-center justify-center text-3xl font-bold shadow">
            {user.name.charAt(0)}
          </div>

          <div>
            <h2 className="text-lg font-semibold">{user.name}</h2>
            <p className="text-gray-500 text-sm">{user.role}</p>
          </div>

          <div className="text-sm text-gray-600 space-y-2 mt-4">
            <div className="flex items-center justify-center gap-2">
              <FaEnvelope /> {user.email}
            </div>
            <div className="flex items-center justify-center gap-2">
              <FaPhone /> {user.phone}
            </div>
          </div>

          <button className="mt-4 w-full bg-red-500 text-white py-2 rounded-lg hover:bg-red-600 transition">
            Logout
          </button>
        </motion.div>

        {/* RIGHT EDIT SECTION */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-md border border-gray-100 space-y-6">
          <h2 className="text-lg font-semibold text-gray-700">
            Edit Information
          </h2>

          <div className="grid md:grid-cols-2 gap-4">
            <Input
              label="Full Name"
              name="name"
              value={user.name}
              onChange={handleChange}
            />

            <Input
              label="Email Address"
              name="email"
              value={user.email}
              onChange={handleChange}
            />

            <Input
              label="Phone Number"
              name="phone"
              value={user.phone}
              onChange={handleChange}
            />

            <div>
              <label className="text-sm text-gray-600">Role</label>
              <div className="mt-1 flex items-center gap-2 p-2 border rounded-lg bg-gray-100 text-gray-600">
                <FaUserShield /> {user.role}
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <button className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition">
              Save Changes
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

/* Reusable Input */
const Input = ({ label, name, value, onChange }) => (
  <div>
    <label className="text-sm text-gray-600">{label}</label>
    <input
      type="text"
      name={name}
      value={value}
      onChange={onChange}
      className="w-full mt-1 p-2 border rounded-lg focus:ring-2 focus:ring-indigo-400 outline-none"
    />
  </div>
);

export default Profile;