import React, { useState } from "react";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import PageWrapper from "../PageWrapper";
import { useNavigate } from "react-router-dom";

function Register() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Email regex
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  // Password rules
  const passwordRegex = {
    lower: /[a-z]/,
    upper: /[A-Z]/,
    number: /\d/,
    special: /[@.#$!%^&*.?]/,
    length: /.{8,}/,
  };

  // Input change
  const handleChange = (e) => {
    setForm((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  // Submit
  const handleSubmit = (e) => {
    e.preventDefault();

    let newErrors = {};

    // Name validation
    if (form.name.trim().length < 3)
      newErrors.name = "Name must be at least 3 characters";

    // Email validation
    if (!emailRegex.test(form.email)) newErrors.email = "Invalid email format";

    // Password validation
    if (!passwordRegex.lower.test(form.password))
      newErrors.password = "Must contain lowercase";
    else if (!passwordRegex.upper.test(form.password))
      newErrors.password = "Must contain uppercase";
    else if (!passwordRegex.number.test(form.password))
      newErrors.password = "Must contain number";
    else if (!passwordRegex.special.test(form.password))
      newErrors.password = "Must contain special character";
    else if (!passwordRegex.length.test(form.password))
      newErrors.password = "Minimum 8 characters";

    // Confirm password
    if (form.password !== form.confirmPassword)
      newErrors.confirmPassword = "Passwords do not match";

    // Stop if errors
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    // Success
    setErrors({});
    console.log("Registered:", form);

    // Redirect to login page
    navigate("/login", { replace: true });
  };

  return (
    <PageWrapper>
      <div className="min-h-screen flex items-center justify-center bg-linear-to-br from-green-500 to-blue-500 px-4">
        <form
          onSubmit={handleSubmit}
className="bg-white/90 backdrop-blur-lg p-8 rounded-2xl shadow-2xl w-full max-w-md space-y-5"        >
          <h2 className="text-2xl font-bold text-center">Create Account</h2>

          {/* Name */}
          <input
            type="text"
            name="name"
            placeholder="Full Name"
            className="w-full border p-2 rounded"
            value={form.name}
            onChange={handleChange}
          />
          {errors.name && <p className="text-red-500 text-sm">{errors.name}</p>}

          {/* Email */}
          <input
            type="text"
            name="email"
            placeholder="Email"
            className="w-full border p-2 rounded"
            value={form.email}
            onChange={handleChange}
          />
          {errors.email && (
            <p className="text-red-500 text-sm">{errors.email}</p>
          )}

          {/* Password */}
          <div className="relative">
            <input
              type={showPassword ? "text" : "password"}
              name="password"
              placeholder="Password"
              className="w-full border p-2 rounded pr-10"
              value={form.password}
              onChange={handleChange}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-3 text-gray-600"
            >
              {showPassword ? <FaEyeSlash /> : <FaEye />}
            </button>
          </div>
          {errors.password && (
            <p className="text-red-500 text-sm">{errors.password}</p>
          )}

          {/* Confirm Password */}
          <div className="relative">
            <input
              type={showConfirmPassword ? "text" : "password"}
              name="confirmPassword"
              placeholder="Confirm Password"
              className="w-full border p-2 rounded pr-10"
              value={form.confirmPassword}
              onChange={handleChange}
            />
            <button
              type="button"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              className="absolute right-3 top-3 text-gray-600"
            >
              {showConfirmPassword ? <FaEyeSlash /> : <FaEye />}
            </button>
          </div>
          {errors.confirmPassword && (
            <p className="text-red-500 text-sm">{errors.confirmPassword}</p>
          )}

          {/* Register Button */}
          <button className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition">
            Register
          </button>
        </form>
      </div>
    </PageWrapper>
  );
}

export default Register;
