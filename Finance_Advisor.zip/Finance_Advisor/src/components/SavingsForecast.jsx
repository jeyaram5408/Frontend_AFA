import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts";

const SavingsForecast = ({ savings = 0 }) => {
  const base = Number(savings);

  const data = [
    { month: "Month 1", value: base },
    { month: "Month 2", value: base *1.1 },
    { month: "Month 3", value: base * 1.2  },
    { month: "Month 4", value: base * 1.3  },
  ];

  return (
    <div className="bg-white p-6 rounded-2xl shadow-md border min-h-80">
      <h3 className="text-lg font-semibold mb-4">
        Savings Forecast
      </h3>

      <ResponsiveContainer width="100%" height={260}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="month" />
          <YAxis />
          <Tooltip formatter={(value) => `₹ ${value}`} />
          <Line
            type="monotone"
            dataKey="value"
            stroke="#4F46E5"
            strokeWidth={3}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default SavingsForecast;