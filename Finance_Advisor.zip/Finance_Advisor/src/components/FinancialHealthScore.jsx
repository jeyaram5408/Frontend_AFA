import React, { useMemo } from "react";
import { calculateFinancialHealth } from "../Utils/financial_calculater";

const FinancialHealthScore = ({ transactions }) => {
const { score } = useMemo(
  () => calculateFinancialHealth(transactions),
  [transactions]
);
  return (
    <div className="bg-white p-6 rounded-2xl shadow-md border border-gray-100">
      <h3 className="text-xl font-semibold mb-4">
        Financial Health Score
      </h3>

      <div className="text-4xl font-bold text-indigo-600">
        {score} <span className="text-gray-400 text-lg">/ 100</span>
      </div>

    <div className="mt-4 w-full bg-gray-200 rounded-full h-3 overflow-hidden">
  <div
    className={`h-full transition-all duration-700 ${
      score >= 70
        ? "bg-green-500"
        : score >= 40
        ? "bg-yellow-500"
        : "bg-red-500"
    }`}
style={{ width: `${Math.min(score, 100)}%` }}  ></div>
</div>
    </div>
  );
};

export default FinancialHealthScore;