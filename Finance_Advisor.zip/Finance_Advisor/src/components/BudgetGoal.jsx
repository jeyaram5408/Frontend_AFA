import React from "react";

const BudgetGoal = () => {

  const goal = 8000
  const saving = 4500

  const progress = (saving / goal) * 100

  return (
    <div className="bg-white border shadow-lg rounded-xl p-6">

      <h2 className="text-xl font-bold mb-4">
        🎯 Monthly Budget Goal
      </h2>

      <p>Goal Amount : ₹{goal}</p>
      <p>Current Saving : ₹{saving}</p>

      {/* Progress Bar */}
      <div className="w-full bg-gray-200 rounded-full h-4 mt-4">

        <div
          className="bg-indigo-600 h-4 rounded-full"
          style={{ width: `${progress}%` }}
        ></div>

      </div>

      <p className="mt-2 text-sm">
        Progress : {progress.toFixed(0)}%
      </p>

    </div>
  );
};

export default BudgetGoal;