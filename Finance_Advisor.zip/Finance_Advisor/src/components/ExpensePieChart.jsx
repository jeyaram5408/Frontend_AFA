import React from "react";
import { motion } from "framer-motion";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const COLORS = [
  "#4F46E5",
  "#EF4444",
  "#F59E0B",
  "#10B981",
  "#6366F1",
  "#EC4899",
];

const ExpensePieChart = ({ transactions = [] }) => {
  const expenseTransactions = transactions.filter(
    (t) => t.type?.toLowerCase() === "expense"
  );

const categoryData = expenseTransactions.reduce((acc, curr) => {
  const normalizedCategory = curr.category
    ? curr.category.trim().toLowerCase()
    : "other";

  const existing = acc.find(
    (item) => item.name.toLowerCase() === normalizedCategory
  );

  if (existing) {
    existing.value += Number(curr.amount);
  } else {
    acc.push({
      name:
        normalizedCategory.charAt(0).toUpperCase() +
        normalizedCategory.slice(1),
      value: Number(curr.amount),
    });
  }

  return acc;
}, []);

  if (categoryData.length === 0) {
    return (
      <div className="bg-white p-6 rounded-2xl shadow-md border min-h-50 flex items-center justify-center">
        <p className="text-gray-400">No expense data available</p>
      </div>
    );
  }

  return (
    <motion.div
  initial={{ opacity: 0, y: 50 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.8 }}
>
    <div className="bg-white p-6 rounded-2xl shadow-md border min-h-75">
      <h3 className="text-lg font-semibold mb-4">Expense Breakdown</h3>

      <ResponsiveContainer width="100%" height={280}>
        <PieChart>
          <Pie
            data={categoryData}
            dataKey="value"
            nameKey="name"
            outerRadius={100}
            label
          >
            {categoryData.map((entry, index) => (
              <Cell key={index} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip formatter={(value) => `₹ ${value.toLocaleString()}`} />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
    </motion.div>
  );
};

export default ExpensePieChart;