import React from "react";

const SmartRecommendations = ({ income = 0, expense = 0 }) => {
  if (!income || income === 0) {
    return (
      <div className="bg-white p-6 rounded-2xl shadow-md border border-gray-100">
        <h2 className="text-xl font-bold mb-4">
          ✨ AI Smart Budget Recommendation
        </h2>
        <p className="text-gray-500">
          Add income to see AI budget suggestions.
        </p>
      </div>
    );
  }

  const needs = income * 0.5;
  const wants = income * 0.3;
  const savings = income * 0.2;

  const expenseRatio = expense / income;

  let insight = "You're managing your finances well!";
  let insightColor = "text-green-600";

  if (expenseRatio > 0.7) {
    insight = "⚠️ Your spending is high. Try reducing unnecessary expenses.";
    insightColor = "text-red-600";
  } else if (expenseRatio > 0.5) {
    insight = "💡 You can slightly improve your savings rate.";
    insightColor = "text-yellow-600";
  }

  return (
    <div className="bg-white p-6 rounded-2xl shadow-md border border-gray-100 space-y-6">
      <h2 className="text-xl font-bold">
        ✨ AI Smart Budget Recommendation
      </h2>

      <p className={`font-medium ${insightColor}`}>
        {insight}
      </p>

      <div className="grid md:grid-cols-3 gap-4">
        <BudgetCard title="🏠 Needs (50%)" amount={needs} />
        <BudgetCard title="🛍 Wants (30%)" amount={wants} />
        <BudgetCard title="💰 Savings (20%)" amount={savings} />
      </div>
    </div>
  );
};

function BudgetCard({ title, amount }) {
  return (
    <div className="bg-indigo-50 p-4 rounded-lg">
      <h4 className="font-semibold text-indigo-700">{title}</h4>
      <p className="text-lg font-bold mt-1">
        ₹ {amount.toFixed(0)}
      </p>
    </div>
  );
}

export default SmartRecommendations;